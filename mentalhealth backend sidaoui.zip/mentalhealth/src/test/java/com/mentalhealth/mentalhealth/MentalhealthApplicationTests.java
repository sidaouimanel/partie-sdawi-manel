package com.mentalhealth.mentalhealth;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import Models.Rservation;
import Repositories.ReservationRepository;
import Services.ReservationService;

import java.util.Optional;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
class MentalhealthApplicationTests {

    @Autowired
    private ReservationService reservationService;

    @MockBean
    private ReservationRepository reservationRepository;

    @Test
    void testSaveReservation() {
        Rservation reservation = new Rservation();
        when(reservationRepository.save(any(Rservation.class))).thenReturn(reservation);
        Rservation savedReservation = reservationService.saveReservation(reservation);
        assertEquals(reservation, savedReservation);
    }

    @Test
    void testUpdateReservation() {
        Long id = (long) 2;
        Rservation existingReservation = new Rservation(id, "2024-05-10", "Raison existante");
        Rservation updatedReservation = new Rservation(id, "2024-05-11", "Nouvelle raison");
        when(reservationRepository.findById(id)).thenReturn(Optional.of(existingReservation));
        when(reservationRepository.save(any(Rservation.class))).thenReturn(updatedReservation);
        Rservation result = reservationService.updateReservation(id, updatedReservation);
        assertEquals(updatedReservation, result);
    }

    @Test
    void testDeleteReservation() {
        Long id = (long) 1;
        Rservation reservation = new Rservation(id, "2024-05-10", "Raison existante");
        when(reservationRepository.findById(id)).thenReturn(Optional.of(reservation));
        reservationService.deleteReservation(id);
        verify(reservationRepository, times(1)).delete(reservation);
    }
}
