package Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import Services.UsersService;
import Models.UsersModel;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("/api/user")
public class UsersController {
    @Autowired
    private UsersService usersService;

    @PostMapping("/register")
    public UsersModel registerUser(@RequestBody UsersModel user) {
        return usersService.registerUser(user.getUsername(), user.getPassword(), user.getEmail(), user.getRole());
    }

    @PostMapping("/login")
    public ResponseEntity<String> authenticateUser(@RequestBody UsersModel user) {
        UsersModel authenticatedUser = usersService.authenticate(user.getUsername(), user.getPassword());
        if (authenticatedUser != null) {
            return ResponseEntity.ok("login-success");
        } else {
            return ResponseEntity.status(401).body("login-failed");
        }
    }
}
