package Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import Services.MessageService;
import Models.Message;

@RestController
public class MessageController {

    private final MessageService messageService;
    private final JavaMailSender emailSender; // Injectez le JavaMailSender

    @Autowired
    public MessageController(MessageService messageService, JavaMailSender emailSender) {
        this.messageService = messageService;
        this.emailSender = emailSender;
    }

    @PostMapping("/messages")
    public void saveMessage(@RequestBody Message message) {
        System.out.println("Requête POST reçue avec le message : " + message);
        try {
            messageService.saveMessage(message);
            System.out.println("Message enregistré avec succès !");
            // Vérifiez si l'adresse e-mail est présente et envoyez un e-mail si nécessaire
            if (message.getSenderCoordinates() != null && message.getSenderCoordinates().contains("@")) {
                sendEmail(message.getSenderCoordinates(), "Nouveau message reçu", "Votre message a été reçu.");
            }
        } catch (Exception e) {
            System.out.println("Erreur lors de l'enregistrement du message : " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Méthode pour envoyer un e-mail
    private void sendEmail(String to, String subject, String text) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            emailSender.send(message);
            System.out.println("E-mail envoyé avec succès à : " + to);
        } catch (MailException e) {
            System.out.println("Erreur lors de l'envoi de l'e-mail : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
