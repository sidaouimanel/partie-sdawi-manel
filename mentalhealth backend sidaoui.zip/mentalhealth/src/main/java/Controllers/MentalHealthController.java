package Controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import Models.MentalHealthResponse;
import Repositories.MentalHealthRepository;
import Services.MentalHealthService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class MentalHealthController {
    
    private final MentalHealthService mentalHealthService;
    private final MentalHealthRepository mentalHealthRepository;

    @Autowired
    public MentalHealthController(MentalHealthService mentalHealthService, MentalHealthRepository mentalHealthRepository) {
        this.mentalHealthService = mentalHealthService;
        this.mentalHealthRepository = mentalHealthRepository;
    }

    @PostMapping("/mental-health-response")
    public ResponseEntity<MentalHealthResponse> saveResponse(@RequestBody MentalHealthResponse response) {
        if (response == null) {
            return ResponseEntity.badRequest().build(); // Retourne un code 400 Bad Request si la réponse est nulle
        }
        String resultMessage = mentalHealthService.processResponse(response);
        MentalHealthResponse savedResponse = mentalHealthRepository.save(response);
        return ResponseEntity.ok().body(savedResponse);
    }

    @GetMapping("/mental-health-responses")
    public ResponseEntity<List<MentalHealthResponse>> getAllResponses() {
        List<MentalHealthResponse> responses = mentalHealthRepository.findAll();
        if (responses == null) {
            return ResponseEntity.notFound().build(); // Retourne un code 404 Not Found si aucune réponse n'est trouvée
        }
        return ResponseEntity.ok().body(responses);
    }

}
