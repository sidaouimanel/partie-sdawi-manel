package Models;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Rservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String date;
    private String reason; // Modification du nom de la propriété

    public Rservation() {
    }

    public Rservation(Long id, String date, String reason) {
        this.id = id;
        this.date = date;
        this.reason = reason;
    }

    // Getters and setters

    @Override
    public String toString() {
        return "Rservation [id=" + id + ", date=" + date + ", reason=" + reason + "]";
    }

    @Override
    public int hashCode() {
        return Objects.hash(date, id, reason);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Rservation other = (Rservation) obj;
        return Objects.equals(date, other.date) && Objects.equals(id, other.id) && Objects.equals(reason, other.reason);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
