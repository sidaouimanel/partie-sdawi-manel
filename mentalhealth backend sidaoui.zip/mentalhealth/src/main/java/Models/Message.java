package Models;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "messages") 
public class Message {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String content;
    private String senderCoordinates;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getSenderCoordinates() {
        return senderCoordinates;
    }

    public void setSenderCoordinates(String senderCoordinates) {
        this.senderCoordinates = senderCoordinates;
    }

    @Override
    public int hashCode() {
        return Objects.hash(content, id, senderCoordinates);
    }

    public Message(Long id, String content, String senderCoordinates) {
        super();
        this.id = id;
        this.content = content;
        this.senderCoordinates = senderCoordinates;
    }

    @Override
    public String toString() {
        return "Message [id=" + id + ", content=" + content + ", senderCoordinates=" + senderCoordinates + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Message other = (Message) obj;
        return Objects.equals(content, other.content) && Objects.equals(id, other.id)
                && Objects.equals(senderCoordinates, other.senderCoordinates);
    }
    
    public Message() {
    }
}
