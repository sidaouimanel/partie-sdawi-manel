package Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class MentalHealthResponse {
	
	
	
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
	    private String mood;
	    private String concentrationDifficulty;
	    private String sleepDifficulty;
	    private String anxiety;
	    private String energyLevel;
	    private String negativeThoughts;
	    private String motivationLevel;
	    private String fatigue;
	    private String happinessLevel;
	    private String loneliness;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getMood() {
			return mood;
		}
		public void setMood(String mood) {
			this.mood = mood;
		}
		public String getConcentrationDifficulty() {
			return concentrationDifficulty;
		}
		public void setConcentrationDifficulty(String concentrationDifficulty) {
			this.concentrationDifficulty = concentrationDifficulty;
		}
		public String getSleepDifficulty() {
			return sleepDifficulty;
		}
		public void setSleepDifficulty(String sleepDifficulty) {
			this.sleepDifficulty = sleepDifficulty;
		}
		public String getAnxiety() {
			return anxiety;
		}
		public void setAnxiety(String anxiety) {
			this.anxiety = anxiety;
		}
		public String getEnergyLevel() {
			return energyLevel;
		}
		public void setEnergyLevel(String energyLevel) {
			this.energyLevel = energyLevel;
		}
		public String getNegativeThoughts() {
			return negativeThoughts;
		}
		public void setNegativeThoughts(String negativeThoughts) {
			this.negativeThoughts = negativeThoughts;
		}
		public String getMotivationLevel() {
			return motivationLevel;
		}
		public void setMotivationLevel(String motivationLevel) {
			this.motivationLevel = motivationLevel;
		}
		public String getFatigue() {
			return fatigue;
		}
		public void setFatigue(String fatigue) {
			this.fatigue = fatigue;
		}
		public String getHappinessLevel() {
			return happinessLevel;
		}
		public void setHappinessLevel(String happinessLevel) {
			this.happinessLevel = happinessLevel;
		}
		public String getLoneliness() {
			return loneliness;
		}
		public void setLoneliness(String loneliness) {
			this.loneliness = loneliness;
		}

}
