package Services;

public @interface SpringBootTest {

}
