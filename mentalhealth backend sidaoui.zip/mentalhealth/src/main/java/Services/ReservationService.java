package Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import Models.Rservation;
import Repositories.ReservationRepository;

import org.springframework.stereotype.Service;
import java.util.Optional; // Assurez-vous d'importer la classe Optional
import org.springframework.web.server.ResponseStatusException; // Assurez-vous d'importer la classe ResponseStatusException

@Service
public class ReservationService {
    
    private final ReservationRepository reservationRepository;

    @Autowired
    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public Rservation saveReservation(Rservation reservation) {
        return reservationRepository.save(reservation);
    }
    
    public Rservation updateReservation(Long id, Rservation reservationDetails) {
        Rservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Réservation introuvable avec l'id : " + id));
        reservation.setDate(reservationDetails.getDate());
        reservation.setReason(reservationDetails.getReason());
        return reservationRepository.save(reservation);
    }
    
    public void deleteReservation(Long id) {
        Rservation reservation = reservationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Réservation introuvable avec l'id : " + id));
        reservationRepository.delete(reservation);
    }
}
