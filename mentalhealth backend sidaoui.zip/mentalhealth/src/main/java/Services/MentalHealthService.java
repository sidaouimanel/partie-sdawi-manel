package Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Models.MentalHealthResponse;
import Repositories.MentalHealthRepository;


@Service

public class MentalHealthService {
	
	
	private final MentalHealthRepository mentalHealthRepository;

    @Autowired
    public MentalHealthService(MentalHealthRepository mentalHealthRepository) {
        this.mentalHealthRepository = mentalHealthRepository;
    }

    public String processResponse(MentalHealthResponse response) {
        // Logique pour calculer le résultat en fonction des réponses
        // Par exemple, vérifiez les réponses négatives et positives et renvoyez un message correspondant
        if (response.getMood().equals("Très triste") || response.getConcentrationDifficulty().equals("Oui")) {
            return "Il semble que vous pourriez avoir besoin de soutien. N'hésitez pas à demander de l'aide.";
        } else if (response.getSleepDifficulty().equals("Oui") || response.getAnxiety().equals("Oui")) {
            return "Il semble que vous puissiez bénéficier d'un peu de repos et de détente.";
        } else if (response.getEnergyLevel().equals("Très faible") && response.getNegativeThoughts().equals("Oui")) {
            return "Vous pourriez traverser une période difficile. Prenez le temps de vous écouter et de vous reposer.";
        } else if (response.getMotivationLevel().equals("Peu motivé") || response.getFatigue().equals("Oui")) {
            return "Vous pourriez avoir besoin de revoir votre emploi du temps pour inclure plus de temps pour vous-même.";
        } else if (response.getHappinessLevel().equals("Très bas") && response.getLoneliness().equals("Oui")) {
            return "Il pourrait être bénéfique pour vous de chercher des moyens de vous connecter avec les autres.";
        } else {
            return "Félicitations ! Continuez à prendre soin de votre santé mentale.";
        }
    }

}
