package Services;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Models.UsersModel;
import Repositories.UserRepository;

@Service
public class UsersService {
    @Autowired
    private UserRepository userRepository;

    public UsersModel registerUser(String username, String password, String email, String role) {
        if (username != null && password != null && email != null && role != null) {
            UsersModel userModel = new UsersModel();
            userModel.setUsername(username);
            userModel.setPassword(password);
            userModel.setEmail(email);
            userModel.setRole(role);
            return userRepository.save(userModel);
        } else {
            return null;
        }
    }

    public UsersModel authenticate(String username, String password) {
        if (username != null && password != null) {
            Optional<UsersModel> userOptional = userRepository.findByUsername(username);
            if (userOptional.isPresent()) {
                UsersModel user = userOptional.get();
                if (user.getPassword().equals(password)) {
                    return user;
                }
            }
        }
        return null;
    }

}
