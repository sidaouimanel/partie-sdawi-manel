package Services;

import Models.Message;
import Repositories.MessageRepository;
import jakarta.transaction.Transactional;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageService {
    
    private final MessageRepository messageRepository;

    @Autowired
    public MessageService(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }
    
    @Transactional
    public void saveMessage(Message message) {
        try {
            messageRepository.save(message);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors de la sauvegarde du message : " + e.getMessage());
        }
    }

    public List<Message> getAllMessages() {
        return messageRepository.findAll();
    }
}
