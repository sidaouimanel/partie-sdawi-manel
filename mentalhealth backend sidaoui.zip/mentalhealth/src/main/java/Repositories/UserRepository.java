package Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Models.UsersModel;

@Repository
public interface UserRepository extends JpaRepository<UsersModel, Long> {
    Optional<UsersModel> findByUsernameAndPassword(String username, String password);

	Optional<UsersModel> findByUsername(String username);
	
}
